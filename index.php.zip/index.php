

<!DOCTYPE html>

<html lang="ja">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Build with Beauty</title>

	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"> -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<!--フォントオーサム-->
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<!--スタイルシート-->
	<link href="<?php echo get_template_directory_uri(); ?>/css/reset.css" rel="stylesheet">
	<link href="<?php echo get_template_directory_uri(); ?>/css/style.css" rel="stylesheet">

	<!--js-->
	<script src="<?php echo get_template_directory_uri(); ?>/js/base.js"></script>

</head>


<body>

<div class="wrap">


<!--ーーーーーーーーーーーーーーーー
ナビ
ーーーーーーーーーーーーーーーー-->
    <header id="top-head">
        <div class="inner">
            <div id="mobile-head">				
				<a class="logo" href="/">
					<!--Logo-->
					<img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="Build with Beauty">
				</a>
                <div id="nav-toggle">
					<!--ハンバーガーメニュー-->
                    <div>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
            <nav id="global-nav">
                <ul>
					<li class="nav-item">
						<a class="navlink" href="/">TOP<br><span class="nav_min">トップ</span></a>
					</li>
					<li class="nav-item">
						<hr class="nav_hr">
					</li>
					<li class="nav-item">
						<a class="navlink" href="/">NEWS<br><span class="nav_min">お知らせ</span></a>
					</li>
					<li class="nav-item">
						<hr class="nav_hr">
					</li>
					<li class="nav-item">
						<a class="navlink" href="/">TO CLIENT<br><span class="nav_min">企業様サロンオーナー様へ</span></a>
					</li>
					<li class="nav-item">
						<hr class="nav_hr">
					</li>
					<li class="nav-item">
						<a class="navlink" href="/">AIRDRESSER<br><span class="nav_min">美容師さんへ</span></a>
					</li>
					<li class="nav-item">
						<hr class="nav_hr">
					</li>
					<li class="nav-item">
						<a class="navlink" href="/">COMPANY<br><span class="nav_min">会社概要</span></a>
					</li>
					<li class="nav-item">
						<hr class="nav_hr">
					</li>
					<li class="nav-item">
						<a class="navlink" href="/">CONTACT<br><span class="nav_min">お問い合わせ</span></a>
					</li>
                </ul>
            </nav>
        </div>
	</header>

<!--ーーーーーーーーーーーーーーーー
	Top
ーーーーーーーーーーーーーーーー-->
	<section id="topview">
		<div class="wrap_topview">
			<div class="img_topview">
				<!--Top画像-->
			</div>
			<div class="area_topview">
				<!--タイトル-->
				<h2><span>B</span>uild with Beauty</h2>
				<hr class="hr_top">
				<p class="item1_topview">
					<img src="<?php echo get_template_directory_uri(); ?>/img/num1.png" alt="Build with Beauty">
					<span>美容師</span>という<span>仕事</span>をもっと<span>自由</span>に
				</p>
				<p class="item2_topview">
					<img src="<?php echo get_template_directory_uri(); ?>/img/num2.png" alt="Build with Beauty">
					<span>美容師</span>という<span>仕事</span>でもっと<span>裕福</span>に
				</p>
				<p class="item3_topview">
					<img src="<?php echo get_template_directory_uri(); ?>/img/num3.png" alt="Build with Beauty">
					<span>美容師</span>という<span>仕事</span>がもっと<span>素敵</span>に
				</p>
				<hr class="hr_bottom">
			</div>
			<a href="/">
				<span>
				</span>
			</a>
		</div>
	</section>


<!--ーーーーーーーーーーーーーーーー
	About Us
ーーーーーーーーーーーーーーーー-->
	<section id="about">
		<div class="wrap_about">
			<div class="com_ttl ttl_about">
				<!--Logo画像-->
				<img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="Build with Beauty">
				<h2><span>A</span>BOUT US</h2>
				<p>私たちについて</P>
			</div>
			<div class="area_about">
				<h3>ビルドウィズビューティーの<br class="add_line">全く新しい美容師の働き方</h3>
			</div>
			<div class="area_txt">
				<p>個人店からチェーン店まで、様々なサロンでのサロンワークといった業務委託形態の完全フリーなワークスタイル。</p>

				<p>一店舗に留まる働き方ではない為、今まで経験出来なかった刺激や楽しさがここにはあります。</p>

				<p>人材でお困りの企業様、サロンオーナー様。力になります！</p>

				<p>そして独立を目指す美容師さん。私達は個人サロンのプロデュースも行っております。是非あなたの独立の夢のお手伝いをさせて下さい。</p>
			</div>
		</div>
	</section>

<!--ーーーーーーーーーーーーーーーー
	NEWS
ーーーーーーーーーーーーーーーー-->
	<section id="news">
		<div class="wrap_news">
			<div class="com_ttl ttl_news">
				<!--Logo画像-->
				<img src="<?php echo get_template_directory_uri(); ?>/img/news_logo.png" alt="お知らせ">
				<h2>NEWS</h2>
				<p>お知らせ</P>
			</div>
			<div class="area_news">
				<div class="item_news">
					<div class="icon_news">
						<img src="<?php echo get_template_directory_uri(); ?>/img/recruit.png" alt="急募">
					</div>
					<div class="cont_news">
						<p class="area">2019/7/08更新　愛知県アリア</p>
						<p class="station">知多市内　最寄駅は<br>
							名鉄常滑線 朝倉駅 周辺</p>
						<p class="job"><span>職種</span>美容師スタイリスト</p>
						<p>フリーランス派遣</p>
					</div>
					<p class="txt">テキストスペースです。テキストスペースです。テキストスペースです。</p>
					<div class="btn1">
						<a href="/">MORE</a>
					</div>
				</div>
				<div class="item_news">
					<div class="cont_news">
						<p class="area">2019/7/08更新　愛知県アリア</p>
						<p class="station">知多市内　最寄駅は<br>
							名鉄常滑線 朝倉駅 周辺</p>
						<p class="job"><span>職種</span>美容師スタイリスト</p>
						<p>フリーランス派遣</p>
					</div>
					<p class="txt">テキストスペースです。テキストスペースです。テキストスペースです。</p>
					<div class="btn1">
						<a href="/">MORE</a>
					</div>
				</div>
				<div class="item_news">
					<div class="icon_news">
						<img src="<?php echo get_template_directory_uri(); ?>/img/recruit.png" alt="急募">
					</div>
					<div class="cont_news">
						<p class="area">2019/7/08更新　愛知県アリア</p>
						<p class="station">知多市内　最寄駅は<br>
							名鉄常滑線 朝倉駅 周辺</p>
						<p class="job"><span>職種</span>美容師スタイリスト</p>
						<p>フリーランス派遣</p>
					</div>
					<p class="txt">テキストスペースです。テキストスペースです。テキストスペースです。</p>
					<div class="btn1">
						<a href="/">MORE</a>
					</div>
				</div>
				<div class="item_news">

					<div class="cont_news">
						<p class="area">2019/7/08更新　愛知県アリア</p>
						<p class="station">知多市内　最寄駅は<br>
							名鉄常滑線 朝倉駅 周辺</p>
						<p class="job"><span>職種</span>美容師スタイリスト</p>
						<p>フリーランス派遣</p>
					</div>
					<p class="txt">テキストスペースです。テキストスペースです。テキストスペースです。</p>
					<div class="btn1">
						<a href="/">MORE</a>
					</div>
				</div>
			</div>
			
		</div>
	</section>

<!--ーーーーーーーーーーーーーーーー
	To CLIENT
ーーーーーーーーーーーーーーーー-->
	<section id="client">
		<div class="wrap_client">
			<div class="img_client">

			</div>
			<div class="com_ttl ttl_client">
				<!--Logo画像-->
				<div class="item_client">
					<img src="<?php echo get_template_directory_uri(); ?>/img/client_logo.png" alt="クライアント様イメージ">
				</div>
				<h2><span>T</span>O CLIENT</h2>
				<p>企業様・サロンオーナー様へ</P>
				<div class="btn2">
					<a href="/">MORE</a>
				</div>
			</div>
		</div>
	</section>

<!--ーーーーーーーーーーーーーーーー
	HAIRDRESSER
ーーーーーーーーーーーーーーーー-->
	<section id="hairdresser">
		<div class="wrap_hairdresser">
			<div class="img_sp_hairdresser">

			</div>
			<div class="com_ttl ttl_hairdresser">
				<!--Logo画像-->
				<div class="item_hairdresser">
					<img src="<?php echo get_template_directory_uri(); ?>/img/hairdresser_logo.png" alt="美容師"イメージ>
				</div>
				<h2><span>H</span>AIRDRESSER</h2>
				<p>美容師さんへ</P>
				<div class="btn2">
					<a href="/">MORE</a>
				</div>
			</div>
			<div class="img_hairdresser">

			</div>
		</div>
	</section>

<!--ーーーーーーーーーーーーーーーー
	COMPANY
ーーーーーーーーーーーーーーーー-->
	<section id="company">
		<div class="wrap_company">
			<div class="com_ttl ttl_company">
				<!--Logo画像-->
				<div class="item_company">
					<img src="<?php echo get_template_directory_uri(); ?>/img/company_logo.png" alt="会社概要イメージ">
				</div>
				<h2>COMPANY</h2>
				<p>会社概要</P>
				<div class="btn1">
					<a href="/">MORE</a>
				</div>
			</div>
		</div>
	</section>

<!--ーーーーーーーーーーーーーーーー
	CONTACT
ーーーーーーーーーーーーーーーー-->
	<section id="contact">
		<div class="wrap_contact">
			<div class="com_ttl ttl_contact">
				<!--Logo画像-->
				<div class="item_contact">
					<img src="<?php echo get_template_directory_uri(); ?>/img/contact_logo.png" alt="あ問い合わせイメージ">
				</div>
				<h2><span>C</span>ONTACT</h2>
				<p>お問い合わせ</P>
			</div>
			<div class="area_contact">
				<a class="btn3 btn_Tell" href="#">
					<div class="btn3_in">
						<p class="btn_1">対応可能時間/9:00〜22:00(定休日なし)</p>
						<p class="btn_2">0564-73-9370</p>
						<p class="btn_3">お電話でのお問い合わせの方はコチラ</p>
					</div>
				</a>
				<a class="btn3 btn_Email" href="#">
					<div class="btn3_in">
					<p class="btn_1">お問い合わせページからお気軽にお問い合わせください</p>
					<p class="btn_2">EMAIL</p>
					<p class="btn_3">メールでのお問い合わせの方はコチラ</p>
					</div>
				</a>
			</div>
		</div>
	</section>

<!--ーーーーーーーーーーーーーーーー
Footer
ーーーーーーーーーーーーーーーー-->
	<footer id="footer">
		<div class="wrap_footer">
			<div class="footer_logo">
				<!--Logo画像-->
				<img src="<?php echo get_template_directory_uri(); ?>/img/logo_bottom.png" alt="Build with Beauty"> 
			</div>
			<nav class="footer_area">
				<ul>
					<li>
						<a href="/">
							Top
							<br><span  class="nav_sub">トップ<span>
						</a>
					</li>
					<li>
						<a href="/">
							NEWS
							<br><span  class="nav_sub">お知らせ<span>
						</a>
					</li>
					<li>
						<a href="/">
						TO CLIENT
							<br><span  class="nav_sub">企業様・サロンオーナー様へ<span>
						</a>
					</li>
					<li>
						<a href="/">
							HAIRDRESSER
							<br><span  class="nav_sub">美容師さんへ<span>
						</a>
					</li>
					<li>
						<a href="/">
							COMPANY
							<br><span  class="nav_sub">会社概要<span>
						</a>
					</li>
					<li>
						<a href="/">
							CONTACT
							<br><span  class="nav_sub">お問い合わせ<span>
						</a>
					</li>
				</ul>
			</nav>
		</div>

		<!--ーーーーーーーーーーーーーーーー
		コピーライト
		ーーーーーーーーーーーーーーーー-->
		<div>
			<div class="copy">
				<p>&copy; 2019 Test.All Rights Reserved</p>
			</div>
		</div>
	</footer>
</body>
</html>

